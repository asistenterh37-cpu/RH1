# -*- coding: utf-8 -*-
"""VIGIA IA: mosaico ISAPI JPEG autorizado, sin RTSP ni captura de escritorio."""
import io, json, os, queue, threading, time, hashlib, tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET
import requests
from requests.auth import HTTPDigestAuth
from PIL import Image, ImageTk, ImageDraw
import vigia_services as services

DIR=os.path.dirname(os.path.abspath(__file__))
CONFIG=os.path.join(DIR,'mosaico_isapi_config.json')
# Only confirmed channels are prefilled; individual slots are editable.
CHANNELS=[101,201,301,501,601,701,901,1001,1101,1401,1501]
DEFAULT={'url':'','interval':3.0,'slots':[{'name':f'Cámara {i+1}','channel':(str(CHANNELS[i]) if i<9 else ('' if i==9 else str(CHANNELS[i-1]))),'blind':i==9} for i in range(12)],'sequences':[{'name':'Recorrido principal','slots':[1,2,3],'seconds':5}], 'counter_slot':5,'counter_enabled':False,'line_y':.55,'split_x':.5}
try:
 with open(CONFIG,encoding='utf-8') as f: stored=json.load(f)
except (OSError,ValueError): stored={}
CFG={**DEFAULT,**stored}
if len(CFG.get('slots',[]))!=12: CFG['slots']=DEFAULT['slots']
GROUP_NAMES=('Entrada','Salida','Ambos','Caseta')
DEFAULT_GROUPS={'Entrada':[2,4,5], 'Salida':[3,6,1], 'Ambos':[7,8,9,12], 'Caseta':[11]}
if not isinstance(CFG.get('groups'),dict): CFG['groups']={k:list(v) for k,v in DEFAULT_GROUPS.items()}
for key in GROUP_NAMES: CFG['groups'].setdefault(key,[])
# Normalize old or malformed saved groups, and keep each active position once.
seen=set()
for group in GROUP_NAMES:
 cleaned=[]
 for n in CFG['groups'][group]:
  try:n=int(n)
  except (TypeError,ValueError):continue
  if 1<=n<=12 and n not in seen and not CFG['slots'][n-1]['blind']:
   cleaned.append(n);seen.add(n)
 CFG['groups'][group]=cleaned
for n in range(1,13):
 if n not in seen and not CFG['slots'][n-1]['blind']:CFG['groups']['Ambos'].append(n)
ROLES=('Aproximación','Intermedia','Conteo','Validación','Apoyo','Caseta','Sin definir')
DEFAULT_EVENTS=['Contar carros','Contar motos','Contar personas a pie','Vehículo detenido','Contar personas en caseta','Contar carros en carril 1','Contar carros en carril 2','Contar motos en carril 1','Contar motos en carril 2','Barrera abierta demasiado tiempo','Paso en sentido contrario','Vehículo en zona restringida','Persona en zona restringida','Cámara sin imagen','Cámara congelada','Actividad fuera de horario']
EVENT_MIGRATION={'Carros':'Contar carros','Motos':'Contar motos','Carril 1':'Contar carros en carril 1','Carril 2':'Contar carros en carril 2','Barrera':'Barrera abierta demasiado tiempo','Personas':'Contar personas a pie','Intrusión':'Persona en zona restringida','Movimiento':'Actividad fuera de horario'}
raw_catalog=CFG.get('event_catalog',DEFAULT_EVENTS)
if not isinstance(raw_catalog,list):raw_catalog=DEFAULT_EVENTS
CFG['event_catalog']=list(dict.fromkeys(str(x).strip() for x in raw_catalog if isinstance(x,str) and x.strip()))
if not CFG['event_catalog']:CFG['event_catalog']=DEFAULT_EVENTS.copy()
if not isinstance(CFG.get('camera_rules'),dict):CFG['camera_rules']={}
for g,positions in CFG['groups'].items():
 for order,pos in enumerate(positions):
  key=str(pos)
  if key not in CFG['camera_rules']:
   role=('Caseta' if g=='Caseta' else ('Conteo' if pos==CFG.get('counter_slot',5) else ('Aproximación' if order==0 else 'Intermedia')))
   CFG['camera_rules'][key]={'role':role,'events':(['Contar carros','Contar motos','Contar carros en carril 1','Contar carros en carril 2'] if pos==CFG.get('counter_slot',5) else ['Cámara sin imagen'])}
for rule in CFG['camera_rules'].values():
 if isinstance(rule,dict):rule['events']=list(dict.fromkeys(EVENT_MIGRATION.get(x,x) for x in rule.get('events',[]) if isinstance(x,str)))
CFG.setdefault('view_order','Normal')
CFG.setdefault('sequence_seconds',5.0)


def good_url(raw):
 p=urlsplit(raw.strip());return p.scheme in ('http','https') and bool(p.hostname) and not p.username and not p.password and not p.query and p.path in ('','/') and not p.fragment

def save_config():
 with open(CONFIG,'w',encoding='utf-8') as f:json.dump(CFG,f,indent=2,ensure_ascii=False)

class App:
 def __init__(self):
  self.root=tk.Tk(); self.root.title('VIGÍA IA · MOSAICO ISAPI · 12 posiciones');self.root.geometry('1320x760');self.root.minsize(860,540)
  self.root.configure(bg='#101b2b');self.stop=threading.Event();self.worker=None;self.q=queue.Queue(maxsize=100)
  self.frames={};self.photos={};self.preview_window=None;self.preview_photo=None;self.selected=0;self.counter_model=None
  self.last_sha={};self.errors={};self.updated={};self.success={};self.counts={(lane,kind):0 for lane in (1,2) for kind in ('car','motorcycle')}
  self.tracks={};self.next_track=1;self.alert_cooldowns={};self.ai_lock=threading.Lock();self.ai_busy=False;self.ai_model=None;self.ai_last={}
  self.unauthorized=False
  self.url=tk.StringVar(value=CFG['url']);self.username=tk.StringVar();self.password=tk.StringVar()
  self.interval=tk.StringVar(value=str(CFG['interval']));self.count_enabled=tk.BooleanVar(value=CFG['counter_enabled'])
  self.line=tk.DoubleVar(value=CFG['line_y']*100);self.split=tk.DoubleVar(value=CFG['split_x']*100)
  self.status=tk.StringVar(value='Listo. Configurá los canales ISAPI en Asignar cámaras. No se guarda la contraseña.')
  head=tk.Frame(self.root,bg='#101b2b');head.pack(fill='x',padx=10,pady=3)
  tk.Label(head,text='VIGÍA IA  |  MOSAICO ISAPI  |  12 POSICIONES',bg='#101b2b',fg='white',font=('Segoe UI',14,'bold')).pack(anchor='w')
  tk.Label(head,text='Capturas JPEG directas · Sin RTSP · Sin depender de una ventana de Hikvision',bg='#101b2b',fg='#a8cbed').pack(anchor='w')
  form=tk.Frame(self.root,bg='#243449');form.pack(fill='x',padx=10,pady=(0,2))
  for col,label,var,show,width in [(0,'URL del NVR',self.url,None,29),(1,'Usuario',self.username,None,15),(2,'Contraseña',self.password,'•',15),(3,'Intervalo (s)',self.interval,None,7)]:
   tk.Label(form,text=label,bg='#243449',fg='white').grid(row=0,column=col*2,padx=4,pady=3)
   ttk.Entry(form,textvariable=var,show=show,width=width).grid(row=0,column=col*2+1,padx=3,pady=3,sticky='w')
  # La URL ocupa aprox. una cuarta parte de su ancho anterior; no estira al ampliar la ventana.
  form.columnconfigure(1,weight=0)
  actions=tk.Frame(self.root,bg='#101b2b');actions.pack(fill='x',padx=10,pady=2)
  self.startbtn=ttk.Button(actions,text='Iniciar mosaico',command=self.toggle);self.startbtn.pack(side='left',padx=3)
  ttk.Button(actions,text='Asignar cámaras',command=self.configure_slots).pack(side='left',padx=3)
  ttk.Button(actions,text='Descubrir canales',command=self.discover).pack(side='left',padx=3)
  ttk.Button(actions,text='Grupos, Secuencias y Roles',command=self.configure_groups).pack(side='left',padx=3)
  self.view_mode=tk.StringVar(value=CFG.get('view_order','Normal'))
  ttk.Combobox(actions,textvariable=self.view_mode,values=['Normal','Por recorrido'],width=13,state='readonly').pack(side='left',padx=3)
  self.view_mode.trace_add('write',self.change_view_mode)
  ttk.Button(actions,text='Ver cámara grande',command=lambda:self.open_detail(self.selected)).pack(side='left',padx=3)
  ttk.Checkbutton(actions,text='Contador IA (cámara asignada)',variable=self.count_enabled,command=self.apply_counter).pack(side='left',padx=5)
  tools=tk.Frame(self.root,bg='#101b2b');tools.pack(fill='x',padx=10,pady=(0,2))
  ttk.Button(tools,text='Usuarios y Accesos',command=self.user_center).pack(side='left',padx=3)
  ttk.Button(tools,text='Enlace Alertas',command=self.enlace_alertas).pack(side='left',padx=3)
  ttk.Button(tools,text='Análisis Python (IA)',command=self.ai_info).pack(side='left',padx=3)
  tk.Label(self.root,textvariable=self.status,bg='#101b2b',fg='#a8cbed',anchor='w',wraplength=1300).pack(fill='x',padx=14)
  mosaic=tk.Frame(self.root,bg='#101b2b');mosaic.pack(fill='both',expand=True,padx=10,pady=3);self.mosaic=mosaic
  self.tiles=[]
  for r in range(3):mosaic.rowconfigure(r,weight=1,uniform='rows')
  for c in range(4):mosaic.columnconfigure(c,weight=1,uniform='cols')
  for i in range(12):
   panel=tk.Frame(mosaic,bg='#243449',highlightbackground='#3d5470',highlightthickness=1)
   panel.grid(row=i//4,column=i%4,sticky='nsew',padx=3,pady=3)
   pic=tk.Label(panel,bg='#131f30',fg='#a3b4ce',text='SIN LECTURA',font=('Segoe UI',12),compound='center')
   pic.pack(fill='both',expand=True)
   info=tk.Label(panel,bg='#243449',fg='white',anchor='w',font=('Segoe UI',9));info.pack(fill='x')
   for widget in (panel,pic,info):
    widget.bind('<Button-1>',lambda e,k=i:self.select(k))
    widget.bind('<Double-Button-1>',lambda e,k=i:self.open_detail(k))
   self.tiles.append((pic,info))
  below=tk.Frame(self.root,bg='#101b2b');below.pack(fill='x',padx=10)
  self.totaltext=tk.StringVar();self.update_totals()
  tk.Label(below,textvariable=self.totaltext,bg='#101b2b',fg='#8ce5b8',font=('Segoe UI',10,'bold')).pack(side='left')
  ttk.Button(below,text='Reiniciar conteos',command=self.reset_counts).pack(side='right',padx=3)
  ttk.Button(below,text='Ajustar línea de conteo',command=self.counter_settings).pack(side='right',padx=3)
  logbox=tk.Frame(self.root,bg='#101b2b');logbox.pack(fill='x',padx=10,pady=(1,3))
  loghead=tk.Frame(logbox,bg='#101b2b');loghead.pack(fill='x')
  tk.Label(loghead,text='EVENTOS · Estados de cámaras y conteo piloto',bg='#101b2b',fg='white',font=('Segoe UI',9)).pack(side='left')
  ttk.Button(loghead,text='Ver eventos en grande',command=self.show_events).pack(side='right')
  self.log=tk.Text(logbox,height=2,bg='#1c2b40',fg='#d1dfef',font=('Consolas',9));self.log.pack(fill='x')
  self.apply_view_order();self.refresh_tiles();self.root.after(150,self.poll);self.root.protocol('WM_DELETE_WINDOW',self.close)
 def raise_alert(self,camera,event,detail='',severity='info',cooldown=60):
  key=(camera,event);now=time.monotonic()
  if now-self.alert_cooldowns.get(key,-1e10)<cooldown:return
  self.alert_cooldowns[key]=now
  try:services.add_alert(camera,event,detail,severity)
  except Exception as ex:self.write('Error al registrar alerta: '+str(ex)[:70]);return
  self.write(f'ALERTA · Cámara {camera}: {event}' + (' · '+str(detail)[:100] if detail else ''))
 def user_center(self):
  win=tk.Toplevel(self.root);win.title('Usuarios y Accesos · Administrador local');win.geometry('780x490')
  ttk.Label(win,text='Nombre, PIN y estado. Los PIN nuevos se muestran solo al administrador de esta computadora. Los PIN antiguos deben restablecerse una vez. Para quitar acceso, seleccioná la persona y pulsá Revocar.',wraplength=750).pack(padx=12,pady=9)
  tree=ttk.Treeview(win,columns=('name','pin','state'),show='headings',height=11)
  for key,title,width in [('name','Nombre del usuario',360),('pin','PIN',110),('state','Estado',170)]:tree.heading(key,text=title);tree.column(key,width=width)
  tree.pack(fill='both',expand=True,padx=12)
  def refresh():
   for child in tree.get_children():tree.delete(child)
   for r in services.list_users_admin():tree.insert('', 'end', iid=str(r['id']), values=(r['name'],r['pin_display'] if r['active'] else '—','Activo' if r['active'] else 'Revocado'))
  def create():
   name=simpledialog.askstring('Nuevo usuario','Nombre:',parent=win)
   if not name:return
   pin=simpledialog.askstring('Clave','PIN de cuatro dígitos:',show='*',parent=win)
   if pin is None:return
   try:
    services.add_user(name,pin);refresh()
    messagebox.showinfo('Clave creada', f'Usuario: {name}\nPIN asignado: {pin}\n\nCopiá estos datos ahora. La clave no se puede consultar después; solo cambiar.', parent=win)
   except Exception as e:messagebox.showerror('No creado',str(e),parent=win)
  def selected():
   ids=tree.selection()
   if not ids:messagebox.showinfo('Seleccioná usuario','Seleccioná una persona en la lista.',parent=win);return None
   return int(ids[0])
  def revoke():
   uid=selected()
   if uid is None:return
   if messagebox.askyesno('Revocar','¿Desactivar este usuario y sus sesiones activas?',parent=win):services.revoke(uid);refresh()
  def reset():
   uid=selected()
   if uid is None:return
   pin=simpledialog.askstring('Restablecer PIN','Nuevo PIN de cuatro dígitos:',show='*',parent=win)
   if pin is None:return
   try:
    services.reset_pin(uid,pin);refresh()
    messagebox.showinfo('Clave actualizada', f'PIN nuevo: {pin}\n\nCompartilo de forma privada con la persona autorizada. No será visible posteriormente.',parent=win)
   except Exception as e:messagebox.showerror('Error',str(e),parent=win)
  buttons=ttk.Frame(win);buttons.pack(fill='x',padx=12,pady=12)
  for title,callback in [('Crear usuario',create),('Cambiar PIN',reset),('Revocar acceso',revoke)]:ttk.Button(buttons,text=title,command=callback).pack(side='left',padx=5)
  refresh()
 def alert_center(self):
  win=tk.Toplevel(self.root);win.title('Centro de Alertas · Historial persistente');win.geometry('960x540')
  ttk.Label(win,text='Eventos reales registrados por VIGÍA. Aquí NO se inventan alertas del catálogo.',font=('Segoe UI',11)).pack(anchor='w',padx=12,pady=8)
  table=ttk.Treeview(win,columns=('time','cam','event','details'),show='headings')
  for k,title,width in [('time','Fecha / hora',165),('cam','Cámara',80),('event','Evento',260),('details','Detalles',390)]:table.heading(k,text=title);table.column(k,width=width)
  table.pack(fill='both',expand=True,padx=12,pady=6)
  def refresh():
   if not win.winfo_exists():return
   for row in table.get_children():table.delete(row)
   for rec in services.recent_alerts():table.insert('','end',values=(rec['time'],rec['camera'],rec['event'],rec['detail']))
   win.after(4000,refresh)
  refresh()
  ttk.Button(win,text='Abrir visor web local',command=self.open_local_portal).pack(pady=6)
 def open_local_portal(self):
  try:
   import webbrowser
   services.start_local_server()
   if not services.wait_for_server(5):
    raise RuntimeError('El servidor de alertas no respondió. Revisá que el puerto 8765 no esté ocupado.')
   webbrowser.open('http://127.0.0.1:8765')
   self.write('Centro de Alertas HTML LOCAL abierto. 127.0.0.1 solo funciona en esta PC; no se puede compartir como enlace móvil.')
  except Exception as e:messagebox.showerror('Servidor local no disponible',str(e)+'\nInstalá Flask y Werkzeug con INSTALAR_ISAPI.bat')
 def enlace_alertas(self):
  # GitHub Pages serves only the frontend; without a real HTTPS backend, show local preview.
  try:
   import webbrowser
   services.start_local_server()
   if not services.wait_for_server(5):
    raise RuntimeError('El servidor local no responde en 127.0.0.1:8765')
   webbrowser.open('http://127.0.0.1:8765/')
   self.write('Enlace Alertas abierto en esta computadora. Para Internet: publicar Enlace alertas.html y configurar URL HTTPS del servidor.')
  except Exception as e:
   messagebox.showerror('Enlace Alertas',str(e),parent=self.root)
 def open_wifi_portal(self):
  try:
   ip=services.start_mobile_server()
   url=f'http://{ip}:8766/'
   popup=tk.Toplevel(self.root);popup.title('Enlace para celular · misma Wi-Fi');popup.geometry('590x275')
   ttk.Label(popup,text='VIGÍA ALERTAS — enlace local para pruebas',font=('Segoe UI',13,'bold')).pack(pady=10)
   ttk.Label(popup,text='El celular debe estar en la misma red Wi-Fi que esta computadora.\nEste enlace NO funciona por Internet ni con datos móviles.',justify='center').pack(pady=7)
   field=ttk.Entry(popup,width=55);field.insert(0,url);field.configure(state='readonly');field.pack(pady=9)
   def copy():
    self.root.clipboard_clear();self.root.clipboard_append(url)
    messagebox.showinfo('Copiado','Pegá la dirección en WhatsApp solo para probar en la misma Wi-Fi.',parent=popup)
   ttk.Button(popup,text='Copiar enlace para WhatsApp',command=copy).pack(pady=4)
   ttk.Label(popup,text='No enviar PIN por este HTTP: conexión local sin cifrado.\nPara usuarios externos necesitás HTTPS y autenticación reforzada.',justify='center',foreground='#9c3e26').pack(pady=8)
   self.write('Servidor de prueba Wi-Fi activado: '+url)
  except Exception as ex:
   messagebox.showerror('No se pudo abrir enlace móvil',str(ex)+'\nRevisá el Firewall de Windows y ejecutá INSTALAR_ISAPI.bat',parent=self.root)
 def ai_info(self):
  messagebox.showinfo('Análisis de eventos','Motor experimental: detector de carros, motos y personas (YOLO, opcional).\n\nSolo se activan eventos asignados a cada cámara. Cámara sin imagen se detecta sin IA.\n\nNo están implementados: placas, barreras, vehículos detenidos, recorridos automáticos ni notificaciones push en segundo plano.\n\nInstalá INSTALAR_CONTADOR_IA.bat para usar detección. La frecuencia JPEG puede limitar los resultados.')
 def schedule_ai(self,i,im):
  # Use a background worker: no blocking YOLO in the Tk loop.
  rule=CFG.get('camera_rules',{}).get(str(i+1),{})
  events=set(rule.get('events',[]))
  supported={'Contar carros','Contar motos','Contar personas a pie','Contar personas en caseta'}
  needed=events.intersection(supported)
  if not needed or self.ai_busy:return
  now=time.monotonic()
  if now-self.ai_last.get(i,0)<5:return
  self.ai_last[i]=now;self.ai_busy=True
  def job():
   try:
    import numpy as np
    if self.ai_model is None:
     from ultralytics import YOLO
     self.ai_model=YOLO('yolov8n.pt')
    result=self.ai_model.predict(np.asarray(im),classes=[0,2,3],conf=0.38,imgsz=640,verbose=False)[0]
    tally={'car':0,'motorcycle':0,'person':0}
    for b in result.boxes:
     cls=result.names.get(int(b.cls[0]),'')
     if cls in tally:tally[cls]+=1
    self.emit('objects',(i,needed,tally))
   except ImportError:
    self.emit('aierror','Falta ultralytics. Ejecutá INSTALAR_CONTADOR_IA.bat.')
   except Exception as e:self.emit('aierror','Detector IA: '+str(e)[:140])
   finally:self.ai_busy=False
  threading.Thread(target=job,daemon=True).start()
 def show_events(self):
  window=tk.Toplevel(self.root);window.title('VIGÍA IA · Historial de eventos');window.geometry('940x490')
  frame=tk.Frame(window);frame.pack(fill='both',expand=True)
  pane=tk.Text(frame,bg='#1c2b40',fg='white',font=('Consolas',11),wrap='word')
  scroll=ttk.Scrollbar(frame,orient='vertical',command=pane.yview);pane.configure(yscrollcommand=scroll.set)
  scroll.pack(side='right',fill='y');pane.pack(side='left',fill='both',expand=True)
  pane.insert('1.0',self.log.get('1.0','end'));pane.configure(state='disabled')
  self.events_view=pane
 def write(self,message):
  entry=datetime.now().strftime('%H:%M:%S')+'  '+message+'\n'
  self.log.insert('end',entry);self.log.see('end')
  view=getattr(self,'events_view',None)
  if view is not None:
   try:
    if view.winfo_exists():
     view.config(state='normal');view.insert('end',entry);view.see('end');view.config(state='disabled')
   except tk.TclError:pass
 def select(self,i):
  self.selected=i
  self.status.set(f"Seleccionada posición {i+1}. Doble clic para ampliar. Canal ISAPI: {CFG['slots'][i]['channel'] or 'sin asignar'}")
 def refresh_tiles(self):
  for i,(pic,info) in enumerate(self.tiles):
   slot=CFG['slots'][i]
   info.config(text=f"{i+1:02d} · {slot['name']} · "+('CIEGA' if slot['blind'] else 'Canal '+(slot['channel'] or 'PENDIENTE')))
   if slot['blind']:pic.configure(text='POSICIÓN CIEGA',image='');self.photos.pop(i,None)
   elif not slot['channel']:pic.configure(text='CANAL SIN ASIGNAR',image='');self.photos.pop(i,None)
 def configure_slots(self):
  if self.worker and self.worker.is_alive():messagebox.showinfo('Primero detener','Detené el mosaico para editar los canales.');return
  win=tk.Toplevel(self.root);win.title('Asignar las 12 posiciones');win.geometry('565x580')
  tk.Label(win,text='Canal ISAPI = ID real del NVR (101, 201, 301, etc.)').grid(row=0,column=0,columnspan=4,pady=8)
  rows=[]
  for i,slot in enumerate(CFG['slots']):
   name=tk.StringVar(value=slot['name']);channel=tk.StringVar(value=slot['channel']);blind=tk.BooleanVar(value=slot['blind'])
   tk.Label(win,text=str(i+1)).grid(row=i+1,column=0,padx=4)
   ttk.Entry(win,textvariable=name,width=25).grid(row=i+1,column=1,padx=4,pady=3)
   ttk.Entry(win,textvariable=channel,width=9).grid(row=i+1,column=2,padx=4)
   ttk.Checkbutton(win,text='Ciega',variable=blind).grid(row=i+1,column=3,padx=4)
   rows.append((name,channel,blind))
  def apply():
   try:
    slots=[]
    for n,ch,b in rows:
     val=ch.get().strip();inactive=b.get()
     if val and (not val.isdigit() or not 1<=int(val)<=9999):raise ValueError('Canal ISAPI inválido: '+val)
     slots.append({'name':n.get().strip() or 'Sin nombre','channel':val,'blind':inactive})
    active=[s['channel'] for s in slots if s['channel'] and not s['blind']]
    if len(active)!=len(set(active)) and not messagebox.askyesno('Canales repetidos','Algunos canales aparecen en varias posiciones. ¿Deseás conservarlos?'):return
    CFG['slots']=slots;save_config();self.refresh_tiles();win.destroy();self.write('Asignación de 12 posiciones guardada')
   except ValueError as ex:messagebox.showerror('Revisar canales',str(ex))
  ttk.Button(win,text='Guardar posiciones',command=apply).grid(row=14,column=0,columnspan=4,pady=12)
 def change_view_mode(self,*_):
  CFG['view_order']=self.view_mode.get();save_config();self.apply_view_order()
 def apply_view_order(self):
  order=list(range(1,13))
  if self.view_mode.get()=='Por recorrido':
   order=[]
   for group in GROUP_NAMES:
    order.extend(CFG['groups'].get(group,[]))
   order.extend(i for i in range(1,13) if i not in order)
  for display_pos,num in enumerate(order):
   self.tiles[num-1][0].master.grid_configure(row=display_pos//4,column=display_pos%4)
  self.write('Vista ordenada: '+self.view_mode.get()) if hasattr(self,'log') else None
 def configure_groups(self):
  win=tk.Toplevel(self.root);win.title('Grupos, Secuencias y Roles · VIGÍA IA');win.geometry('1180x740');win.minsize(860,560)
  tk.Label(win,text='En cada grupo, el orden de arriba hacia abajo ES la secuencia del recorrido.',font=('Segoe UI',12,'bold')).pack(pady=(8,1))
  tk.Label(win,text='Ordená, asigná rol y eventos. Podés reproducir la secuencia sin alterar la vigilancia del mosaico.').pack(pady=(0,7))
  work={k:list(CFG['groups'].get(k,[])) for k in GROUP_NAMES}
  rules={str(k):{'role':v.get('role','Sin definir'),'events':list(v.get('events',[]))} for k,v in CFG.get('camera_rules',{}).items()}
  for n in range(1,13):rules.setdefault(str(n),{'role':'Sin definir','events':[]})
  # El catálogo pertenece a esta configuración, no a una cámara individual.
  catalog=list(CFG.get('event_catalog',DEFAULT_EVENTS))
  tabs=ttk.Notebook(win);tabs.pack(fill='both',expand=True,padx=12,pady=(0,4))
  event_widgets=[]
  def refresh_event_lists():
   for el in event_widgets:
    previously=[el.get(i) for i in el.curselection()]
    el.delete(0,'end')
    for i,event in enumerate(catalog):
     el.insert('end',event)
     if event in previously:el.selection_set(i)
  def selected_camera_events(group):
   n=current_selection(group)
   return rules[str(n)].get('events',[]) if n is not None else []
  def add_catalog_event():
   name=new_event_var.get().strip()
   if not name or len(name)>100:
    messagebox.showwarning('Nombre inválido','Escribí un evento de 1 a 100 caracteres.',parent=win);return
   if name.casefold() in (x.casefold() for x in catalog):
    messagebox.showinfo('Ya existe','Ese evento ya está en el catálogo.',parent=win);return
   catalog.append(name);catalog_list.insert('end',name);new_event_var.set('');refresh_event_lists()
   self.write('Evento creado en catálogo: '+name)
  def remove_catalog_event():
   sel=catalog_list.curselection()
   if not sel:return
   name=catalog[sel[0]]
   if any(name in r.get('events',[]) for r in rules.values()):
    messagebox.showwarning('Evento asignado','Primero quitá este evento de las cámaras que lo utilizan.',parent=win);return
   del catalog[sel[0]];catalog_list.delete(sel[0]);refresh_event_lists()
  def rename_catalog_event():
   sel=catalog_list.curselection()
   if not sel:return
   old=catalog[sel[0]];new=new_event_var.get().strip()
   if not new or len(new)>100 or (new.casefold()!=old.casefold() and new.casefold() in (x.casefold() for x in catalog)):
    messagebox.showwarning('Nombre inválido','Elegí un nombre diferente de 1 a 100 caracteres.',parent=win);return
   catalog[sel[0]]=new
   for rule in rules.values():rule['events']=[new if e==old else e for e in rule.get('events',[])]
   catalog_list.delete(sel[0]);catalog_list.insert(sel[0],new);refresh_event_lists();new_event_var.set('')
  catalog_tab=ttk.Frame(tabs)
  tabs.add(catalog_tab,text='Catálogo de eventos')
  ttk.Label(catalog_tab,text='Creá, renombrá o quitá eventos. Luego elegí una cámara en su grupo y asignale los eventos del catálogo.',wraplength=850).pack(anchor='w',padx=15,pady=12)
  catalog_body=ttk.Frame(catalog_tab);catalog_body.pack(fill='both',expand=True,padx=15,pady=4)
  catalog_list=tk.Listbox(catalog_body,exportselection=False,font=('Segoe UI',11),height=16)
  catalog_list.pack(side='left',fill='both',expand=True,padx=(0,15))
  cat_buttons=ttk.Frame(catalog_body);cat_buttons.pack(side='right',fill='y')
  ttk.Label(cat_buttons,text='Nombre del evento').pack(anchor='w')
  new_event_var=tk.StringVar()
  ttk.Entry(cat_buttons,textvariable=new_event_var,width=36).pack(fill='x',pady=5)
  ttk.Button(cat_buttons,text='Crear evento',command=add_catalog_event).pack(fill='x',pady=3)
  ttk.Button(cat_buttons,text='Renombrar seleccionado',command=rename_catalog_event).pack(fill='x',pady=3)
  ttk.Button(cat_buttons,text='Quitar seleccionado',command=remove_catalog_event).pack(fill='x',pady=3)
  ttk.Label(cat_buttons,text='Los eventos son etiquetas configurables.\nSu detección automática requiere un módulo\nimplementado y validado.',foreground='#666').pack(anchor='w',pady=20)
  for label in catalog:catalog_list.insert('end',label)
  def use_catalog_selection(e):
   sel=catalog_list.curselection()
   if sel:new_event_var.set(catalog[sel[0]])
  catalog_list.bind('<<ListboxSelect>>',use_catalog_selection)
  lists={};controls_data={}
  def all_refresh():
   for group,lst in lists.items():
    old=lst.curselection();lst.delete(0,'end')
    for j,n in enumerate(work[group]):
     slot=CFG['slots'][n-1];role=rules[str(n)]['role']
     mark='  [CONTEO]' if n==int(counter_choice.get()) else ''
     lst.insert('end',f'{j+1:02d} → Cámara {n:02d} · {slot["name"]} · ISAPI {slot["channel"]} · {role}{mark}')
    if old and old[0]<lst.size():lst.selection_set(old[0])
  def current_selection(group):
   sel=lists[group].curselection()
   return work[group][sel[0]] if sel else None
  def move(group,delta):
   lst=lists[group];sel=lst.curselection()
   if not sel:return
   i=sel[0];j=i+delta
   if j<0 or j>=len(work[group]):return
   work[group][i],work[group][j]=work[group][j],work[group][i]
   all_refresh();lst.selection_clear(0,'end');lst.selection_set(j);lst.see(j)
  def add(group,chosen):
   try:n=int(chosen.get())
   except ValueError:return
   if CFG['slots'][n-1]['blind']:
    messagebox.showwarning('Cámara ciega','No puede incorporarse a un recorrido activo.');return
   for g in GROUP_NAMES:
    if n in work[g]:work[g].remove(n)
   work[group].append(n);all_refresh();lists[group].selection_set(len(work[group])-1)
  def remove(group):
   n=current_selection(group)
   if n is None:return
   work[group].remove(n);all_refresh()
  def set_rule(group,role_var,event_list):
   n=current_selection(group)
   if n is None:return
   rules[str(n)]={'role':role_var.get(),'events':[catalog[i] for i in event_list.curselection()]}
   all_refresh()
  def fill_rule(group,role_var,event_list):
   n=current_selection(group)
   if n is None:return
   rule=rules[str(n)];role_var.set(rule.get('role','Sin definir'))
   event_list.selection_clear(0,'end')
   for j,event in enumerate(catalog):
    if event in rule.get('events',[]):event_list.selection_set(j)
  def save(quiet=False):
   n=int(counter_choice.get())
   if CFG['slots'][n-1]['blind']:
    messagebox.showerror('Posición ciega','El conteo no puede realizarse en una cámara ciega.');return False
   CFG['groups']={k:list(work[k]) for k in GROUP_NAMES}
   CFG['camera_rules']=rules;CFG['counter_slot']=n;CFG['event_catalog']=list(catalog)
   try:seconds=float(seconds_var.get());assert 1<=seconds<=300
   except Exception:messagebox.showerror('Duración inválida','Usá entre 1 y 300 segundos.');return False
   CFG['sequence_seconds']=seconds
   CFG['sequences']=[{'name':g,'slots':list(work[g]),'seconds':seconds} for g in GROUP_NAMES if work[g]]
   save_config();self.apply_view_order();self.refresh_tiles()
   if not quiet:self.write('Grupos, roles, eventos y secuencias guardados')
   return True
  for group in GROUP_NAMES:
   tab=ttk.Frame(tabs);tabs.add(tab,text=group)
   ttk.Label(tab,text='El orden numerado aquí define la secuencia '+group).pack(anchor='w',padx=12,pady=5)
   content=ttk.Frame(tab);content.pack(fill='both',expand=True,padx=10,pady=3)
   left=ttk.Frame(content);left.pack(side='left',fill='both',expand=True)
   lst=tk.Listbox(left,height=12,exportselection=False,font=('Segoe UI',10));lst.pack(fill='both',expand=True)
   lists[group]=lst
   right=ttk.Frame(content);right.pack(side='left',fill='y',padx=12)
   ttk.Button(right,text='↑ Subir',command=lambda g=group:move(g,-1)).pack(fill='x',pady=2)
   ttk.Button(right,text='↓ Bajar',command=lambda g=group:move(g,1)).pack(fill='x',pady=2)
   choices=[f'{n}: {CFG["slots"][n-1]["name"]}' for n in range(1,13) if not CFG['slots'][n-1]['blind']]
   chosen=tk.StringVar(value=choices[0] if choices else '')
   ttk.Label(right,text='Agregar o mover cámara a este grupo').pack(pady=(14,2))
   combo=ttk.Combobox(right,values=choices,textvariable=chosen,width=30,state='readonly');combo.pack(fill='x')
   ttk.Button(right,text='Agregar cámara',command=lambda g=group,v=chosen:add(g,v.get().split(':')[0])).pack(fill='x',pady=4)
   ttk.Button(right,text='Quitar del grupo',command=lambda g=group:remove(g)).pack(fill='x',pady=3)
   ttk.Separator(right).pack(fill='x',pady=10)
   ttk.Label(right,text='Rol de la cámara seleccionada').pack(anchor='w')
   role=tk.StringVar(value='Sin definir')
   ttk.Combobox(right,values=ROLES,textvariable=role,state='readonly',width=27).pack(fill='x',pady=2)
   ttk.Label(right,text='Asignar eventos del catálogo (Ctrl + clic)').pack(anchor='w',pady=(9,2))
   # Lista desplazable: presenta todos los eventos del catálogo, sin cortarlos al octavo.
   event_frame=ttk.Frame(right);event_frame.pack(fill='both',expand=True)
   eventlist=tk.Listbox(event_frame,height=14,width=38,selectmode='extended',exportselection=False)
   eventscroll=ttk.Scrollbar(event_frame,orient='vertical',command=eventlist.yview)
   eventlist.configure(yscrollcommand=eventscroll.set)
   eventlist.pack(side='left',fill='both',expand=True)
   eventscroll.pack(side='right',fill='y')
   for event in catalog:eventlist.insert('end',event)
   event_widgets.append(eventlist)
   ttk.Label(right,text='Desplazate para ver todos; Ctrl + clic selecciona varios.',foreground='#666',wraplength=260).pack(anchor='w',pady=(2,0))
   ttk.Button(right,text='Asignar rol y eventos a cámara',command=lambda g=group,v=role,el=eventlist:set_rule(g,v,el)).pack(fill='x',pady=7)
   lst.bind('<<ListboxSelect>>',lambda e,g=group,v=role,el=eventlist:fill_rule(g,v,el))
  tabs.select(tabs.tabs()[1]) # Abrir directamente en Entrada; el catálogo queda en otra pestaña.
  footer=ttk.Frame(win);footer.pack(fill='x',padx=12,pady=9)
  ttk.Label(footer,text='Cámara de conteo (posición):').pack(side='left')
  counter_choice=tk.StringVar(value=str(CFG.get('counter_slot',5)))
  ttk.Combobox(footer,textvariable=counter_choice,values=[str(n) for n in range(1,13) if not CFG['slots'][n-1]['blind']],state='readonly',width=4).pack(side='left',padx=7)
  ttk.Label(footer,text='Segundos por cámara:').pack(side='left',padx=(15,3))
  seconds_var=tk.StringVar(value=str(CFG.get('sequence_seconds',5)))
  ttk.Entry(footer,textvariable=seconds_var,width=5).pack(side='left')
  def preview_sequence():
   group=tabs.tab(tabs.select(),'text')
   if group not in GROUP_NAMES:
    messagebox.showinfo('Elegí un recorrido','Seleccioná Entrada, Salida, Ambos o Caseta.',parent=win);return
   if not save(True):return
   seq=next((s for s in CFG['sequences'] if s['name']==group),None)
   if not seq or not seq['slots']:messagebox.showinfo('Sin cámaras','Agregá al menos una cámara a este grupo.');return
   self.play_sequence(seq)
  ttk.Button(footer,text='Ver secuencia del grupo',command=preview_sequence).pack(side='right',padx=5)
  ttk.Button(footer,text='Guardar todo',command=lambda:(save() and win.destroy())).pack(side='right',padx=5)
  ttk.Button(footer,text='Cerrar',command=win.destroy).pack(side='right',padx=5)
  all_refresh()
 def configure_sequences(self):
  self.configure_groups()
 def play_sequence(self,sequence):
  self.sequence=sequence;self.sequence_pos=0;self.sequence_running=True
  self.open_detail(sequence['slots'][0]-1)
  def step():
   if not self.sequence_running or self.preview_window is None or not self.preview_window.winfo_exists():return
   self.sequence_pos=(self.sequence_pos+1)%len(sequence['slots']);self.open_detail(sequence['slots'][self.sequence_pos]-1)
   self.root.after(int(sequence['seconds']*1000),step)
  self.root.after(int(sequence['seconds']*1000),step)
 def open_detail(self,i):
  self.selected=i
  if self.preview_window is None or not self.preview_window.winfo_exists():
   self.preview_window=tk.Toplevel(self.root);self.preview_window.geometry('1000x740');self.preview_window.title('VIGÍA · Vista ampliada')
   self.preview_label=tk.Label(self.preview_window,bg='#09111c',fg='white',text='Esperando imagen...',font=('Segoe UI',17));self.preview_label.pack(fill='both',expand=True)
   self.preview_window.protocol('WM_DELETE_WINDOW',self.close_detail)
  self.preview_window.title(f"VIGÍA IA · Vista grande · {i+1}: {CFG['slots'][i]['name']}")
  self.update_detail()
 def close_detail(self):
  self.sequence_running=False
  if self.preview_window:self.preview_window.destroy()
  self.preview_window=None
 def update_detail(self):
  if self.preview_window is None or not self.preview_window.winfo_exists():return
  pic=self.frames.get(self.selected)
  if pic:
   im=pic.copy();im.thumbnail((max(500,self.preview_label.winfo_width()-15),max(420,self.preview_label.winfo_height()-15)),Image.Resampling.LANCZOS)
   self.preview_photo=ImageTk.PhotoImage(im);self.preview_label.configure(image=self.preview_photo,text='')
  else:self.preview_label.configure(image='',text='Sin imagen para esta posición')
 def apply_counter(self):
  CFG['counter_enabled']=bool(self.count_enabled.get());save_config();self.write('Contador IA '+('activado' if CFG['counter_enabled'] else 'desactivado'))
 def counter_settings(self):
  win=tk.Toplevel(self.root);win.title('Contador: línea y carriles');win.geometry('420x230')
  v=tk.StringVar(value=str(CFG['counter_slot']))
  ttk.Label(win,text='Posición para contar (1–12)').pack(pady=4);ttk.Entry(win,textvariable=v).pack()
  ttk.Label(win,text='Línea horizontal Y %').pack();ttk.Scale(win,from_=10,to=90,variable=self.line).pack(fill='x',padx=30)
  ttk.Label(win,text='Separación de carriles X %').pack();ttk.Scale(win,from_=10,to=90,variable=self.split).pack(fill='x',padx=30)
  def save():
   try:
    n=int(v.get());assert 1<=n<=12
    CFG.update(counter_slot=n,line_y=self.line.get()/100,split_x=self.split.get()/100);save_config();win.destroy()
   except Exception:messagebox.showerror('Error','Elegí una posición del 1 al 12.')
  ttk.Button(win,text='Guardar',command=save).pack(pady=10)
 def reset_counts(self):
  self.counts={(lane,kind):0 for lane in (1,2) for kind in ('car','motorcycle')};self.tracks={};self.next_track=1;self.update_totals();self.write('Conteos reiniciados')
 def update_totals(self):
  c=self.counts;self.totaltext.set(f"CARRIL 1 · Autos {c[(1,'car')]} / Motos {c[(1,'motorcycle')]}     |     CARRIL 2 · Autos {c[(2,'car')]} / Motos {c[(2,'motorcycle')]}")
 def credentials(self):
  url=self.url.get().strip().rstrip('/')
  if not good_url(url):messagebox.showerror('URL incorrecta','Indicá http(s)://servidor:puerto sin rutas.');return None
  if not self.username.get() or not self.password.get():messagebox.showerror('Credenciales','Ingresá el usuario y contraseña autorizados. No se guardan.');return None
  return url,self.username.get(),self.password.get()
 def discover(self):
  creds=self.credentials()
  if not creds:return
  def job():
   try:
    url,u,p=creds
    response=requests.get(url+'/ISAPI/Streaming/channels',auth=HTTPDigestAuth(u,p),timeout=(4,12),allow_redirects=False)
    response.raise_for_status();root=ET.fromstring(response.content)
    result=[]
    for chan in root.iter():
     if chan.tag.split('}')[-1]!='StreamingChannel':continue
     idn=next((e.text for e in chan if e.tag.split('}')[-1]=='id'),None)
     if idn and idn.isdigit() and int(idn)%100==1:result.append(int(idn))
    self.emit('discovery',sorted(set(result)))
   except Exception as ex:self.emit('error',(-1,'Descubrimiento: '+str(ex)))
  threading.Thread(target=job,daemon=True).start();self.status.set('Consultando la lista ISAPI de canales...')
 def toggle(self):
  if self.worker and self.worker.is_alive():self.stop.set();self.startbtn.config(text='Deteniendo...',state='disabled');self.status.set('Deteniendo consultas...');return
  creds=self.credentials()
  if not creds:return
  try:
   interval=float(self.interval.get());assert 1<=interval<=30
  except Exception:messagebox.showerror('Intervalo inválido','Usá entre 1 y 30 segundos; empezá con 3.');return
  if not any(s['channel'] and not s['blind'] for s in CFG['slots']):messagebox.showerror('Sin canales','Asigná al menos un canal ISAPI.');return
  CFG['url']=creds[0];CFG['interval']=interval;save_config()
  self.unauthorized=False;self.stop.clear();self.worker=threading.Thread(target=self.loop,args=(*creds,interval),daemon=True);self.worker.start()
  self.startbtn.config(text='Detener mosaico');self.status.set('Conectando cámaras por ISAPI...')
 def emit(self,k,data):
  try:self.q.put_nowait((k,data))
  except queue.Full:pass
 def fetch(self,slot,channel,base,auth):
  if self.stop.is_set():return
  try:
   r=requests.get(f'{base}/ISAPI/Streaming/channels/{channel}/picture',auth=auth,params={'_vigia':str(time.time_ns())},timeout=(4,9),allow_redirects=False,headers={'Accept':'image/jpeg','Cache-Control':'no-cache'})
   if r.status_code!=200:raise RuntimeError('HTTP '+str(r.status_code))
   if len(r.content)>12_000_000:raise RuntimeError('Respuesta mayor de 12 MB')
   if not r.content.startswith(b'\xff\xd8'):raise RuntimeError('Respuesta no es JPEG')
   im=Image.open(io.BytesIO(r.content));im.load();im=im.convert('RGB')
   digest=hashlib.sha256(r.content).digest()
   self.emit('frame',(slot,im,digest,time.time()))
  except Exception as ex:self.emit('error',(slot,str(ex)[:100]))
 def loop(self,base,user,password,interval):
  auth=HTTPDigestAuth(user,password)
  with ThreadPoolExecutor(max_workers=3) as pool:
   while not self.stop.is_set():
    start=time.monotonic()
    futures=[]
    for i,s in enumerate(CFG['slots']):
     if s['blind'] or not s['channel']:continue
     futures.append(pool.submit(self.fetch,i,s['channel'],base,auth))
    for fut in futures:
     try:fut.result(timeout=15)
     except Exception:pass
    elapsed=time.monotonic()-start
    self.stop.wait(max(.1,interval-elapsed))
  self.emit('stopped',None)
 def poll(self):
  for _ in range(30):
   try:kind,data=self.q.get_nowait()
   except queue.Empty:break
   if kind=='frame':
    i,im,digest,at=data;was_error=i in self.errors;self.errors.pop(i,None)
    same=self.last_sha.get(i)==digest;self.last_sha[i]=digest;self.frames[i]=im;self.updated[i]=at;self.success[i]=self.success.get(i,0)+1
    if was_error:self.write(f"Cámara {i+1}: conexión recuperada")
    if CFG['counter_enabled'] and i==CFG['counter_slot']-1 and not same:self.count_image(im)
    if not same:self.schedule_ai(i,im)
    self.render(i,im)
    if self.preview_window and self.selected==i:self.update_detail()
   elif kind=='error':
    i,msg=data
    if i<0:self.write(msg);self.status.set(msg)
    else:
     if 'HTTP 401' in msg and not self.unauthorized:
      self.unauthorized=True;self.stop.set();self.write('ACCESO RECHAZADO (401): consultas detenidas para evitar bloqueo de cuenta.')
      messagebox.showwarning('ISAPI 401','El NVR rechazó la autenticación. Se detuvieron las consultas automáticas. Revisá usuario/permisos antes de reintentar.')
     if self.errors.get(i)!=msg:self.write(f"Cámara {i+1}: sin lectura ({msg})")
     self.errors[i]=msg
     if '401' not in msg and 'Cámara sin imagen' in CFG.get('camera_rules',{}).get(str(i+1),{}).get('events',[]):self.raise_alert(i+1,'Cámara sin imagen',msg,'warning',cooldown=300)
     self.tiles[i][1].config(fg='#ffbd82',text=f'{i+1:02d} · {CFG["slots"][i]["name"]} · ERROR {msg[:22]}')
   elif kind=='objects':
    i,needed,tally=data
    if 'Contar carros' in needed and tally['car']:
     self.raise_alert(i+1,'Carros presentes',f"Detecciones en una imagen: {tally['car']}; NO es conteo de cruces",cooldown=90)
    if 'Contar motos' in needed and tally['motorcycle']:
     self.raise_alert(i+1,'Motos presentes',f"Detecciones en una imagen: {tally['motorcycle']}; NO es conteo de cruces",cooldown=90)
    if 'Contar personas a pie' in needed and tally['person']:
     self.raise_alert(i+1,'Personas detectadas',f"Detecciones en una imagen: {tally['person']}",cooldown=90)
    if 'Contar personas en caseta' in needed and tally['person']:
     self.raise_alert(i+1,'Personas en caseta (posibles)',f"Detecciones: {tally['person']}",cooldown=90)
   elif kind=='aierror':
    if not getattr(self,'aierror_shown',False):self.aierror_shown=True;self.write(data)
   elif kind=='discovery':
    ids=data;self.status.set(f'Descubiertos {len(ids)} canales principales: '+', '.join(map(str,ids)))
    self.write('Canales principales ISAPI encontrados: '+', '.join(map(str,ids)))
    messagebox.showinfo('Canales detectados','Canales principales encontrados:\n'+', '.join(map(str,ids))+'\n\nUsá Asignar cámaras para definir la posición de cada uno.')
   elif kind=='stopped':self.startbtn.config(text='Iniciar mosaico',state='normal');self.status.set('Mosaico detenido.')
  if self.worker and self.worker.is_alive() and not self.stop.is_set():
   count=len(self.updated);errors=len(self.errors)
   self.status.set(f'{datetime.now():%H:%M:%S} · {count} posiciones con JPEG recibido · {errors} errores recientes · ISAPI sin RTSP · intervalo nominal {CFG["interval"]} s')
  self.root.after(150,self.poll)
 def render(self,i,im):
  pic,info=self.tiles[i];w=max(120,pic.winfo_width()-9);h=max(85,pic.winfo_height()-9)
  rendered=im.copy()
  if CFG['counter_slot']==i+1 and CFG['counter_enabled']:
   draw=ImageDraw.Draw(rendered)
   y=int(im.height*CFG['line_y']);x=int(im.width*CFG['split_x']);draw.line([(0,y),(im.width,y)],fill='#ffd83b',width=4);draw.line([(x,0),(x,im.height)],fill='#54c7ff',width=3)
  rendered.thumbnail((w,h),Image.Resampling.LANCZOS)
  photo=ImageTk.PhotoImage(rendered);self.photos[i]=photo;pic.config(image=photo,text='')
  info.config(text=f"{i+1:02d} · {CFG['slots'][i]['name']} · {datetime.fromtimestamp(self.updated[i]):%H:%M:%S} · {im.width}×{im.height}",fg='#7de7ad')
 def count_image(self,pic):
  try:
   if self.counter_model is None:
    from ultralytics import YOLO
    self.counter_model=YOLO('yolov8n.pt');self.write('Detector YOLO cargado')
   import numpy as np
   result=self.counter_model.predict(np.array(pic),classes=[2,3],conf=.30,imgsz=640,verbose=False)[0]
   detected=[]
   for b in result.boxes:
    label=result.names.get(int(b.cls[0]),'')
    if label not in ('car','motorcycle'):continue
    x1,y1,x2,y2=[float(x) for x in b.xyxy[0].tolist()]
    detected.append((label,(x1+x2)/2,y2))
   unmatched=set(range(len(detected)))
   for tid,tr in list(self.tracks.items()):
    options=sorted(((((x-tr['x'])**2+(y-tr['y'])**2)**.5,j) for j,(cls,x,y) in enumerate(detected) if j in unmatched and cls==tr['class']))
    if not options or options[0][0]>pic.width*.2:
     tr['missed']+=1
     if tr['missed']>3:del self.tracks[tid]
     continue
    _,j=options[0];unmatched.discard(j);cls,x,y=detected[j];line=pic.height*CFG['line_y']
    margin=pic.height*.015
    if not tr['counted'] and ((tr['y']<line-margin and y>=line+margin) or (tr['y']>line+margin and y<=line-margin)):
     lane=1 if x<pic.width*CFG['split_x'] else 2
     self.counts[(lane,cls)]+=1;tr['counted']=True;self.write(f'Conteo piloto · Carril {lane} · {cls} +1')
    tr.update(x=x,y=y,missed=0)
   for j in unmatched:
    cls,x,y=detected[j];self.tracks[self.next_track]={'class':cls,'x':x,'y':y,'missed':0,'counted':False};self.next_track+=1
   self.update_totals()
  except Exception as ex:
   CFG['counter_enabled']=False;self.count_enabled.set(False);self.write('Detector IA no disponible: '+str(ex)[:100]);self.status.set('Contador IA desactivado. Instalá INSTALAR_CONTADOR_IA.bat')
 def close(self):self.stop.set();self.sequence_running=False;self.root.destroy()

if __name__=='__main__':App().root.mainloop()

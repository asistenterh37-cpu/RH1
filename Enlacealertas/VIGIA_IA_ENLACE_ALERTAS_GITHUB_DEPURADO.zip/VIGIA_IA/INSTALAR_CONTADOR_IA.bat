@echo off
cd /d "%~dp0"
py -3 -m pip install --upgrade ultralytics opencv-python
if errorlevel 1 (
  echo ERROR: no se pudo instalar el detector de carros y motos.
  echo Revisa Python 3, permisos y conexion a Internet.
  pause
  exit /b 1
)
echo Instalacion del contador IA terminada.
pause

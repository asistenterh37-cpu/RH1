@echo off
cd /d "%~dp0"
py -3 -m pip install Pillow requests flask werkzeug
if errorlevel 1 (echo ERROR instalando dependencias. & pause & exit /b 1)
echo Dependencias de VIGIA ISAPI y Centro de Alertas instaladas.
echo Para activar deteccion IA, ejecutar INSTALAR_CONTADOR_IA.bat.
pause

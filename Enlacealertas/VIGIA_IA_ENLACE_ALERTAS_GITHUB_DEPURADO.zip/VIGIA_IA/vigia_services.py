"""VIGIA: almacenamiento de eventos, cuentas revocables y visor WEB LOCAL.
El servidor solo escucha en 127.0.0.1; no exponer por Internet sin HTTPS,
autenticación adicional, y revisión de seguridad.
"""
import os, sqlite3, threading, time, secrets, json, urllib.request, socket, base64
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(ROOT,'vigia_alertas.db')
_LOCK=threading.RLock()


# El PIN sigue verificándose mediante un hash. Una copia cifrada por Windows
# DPAPI se usa exclusivamente para la tabla de administración local.
def _dpapi(data, decrypt=False):
 if os.name != 'nt':
  raise RuntimeError('El almacenamiento cifrado visible requiere Windows')
 import ctypes
 from ctypes import wintypes
 class BLOB(ctypes.Structure):
  _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]
 raw=data if isinstance(data,bytes) else data.encode('utf-8')
 src=ctypes.create_string_buffer(raw)
 inblob=BLOB(len(raw),ctypes.cast(src,ctypes.POINTER(ctypes.c_byte)))
 outblob=BLOB()
 crypt=ctypes.windll.crypt32
 if decrypt:
  ok=crypt.CryptUnprotectData(ctypes.byref(inblob),None,None,None,None,0,ctypes.byref(outblob))
 else:
  ok=crypt.CryptProtectData(ctypes.byref(inblob),'VIGIA PIN',None,None,None,0,ctypes.byref(outblob))
 if not ok:raise ctypes.WinError()
 try:return ctypes.string_at(outblob.pbData,outblob.cbData)
 finally:ctypes.windll.kernel32.LocalFree(outblob.pbData)

def _protected_pin(pin):
 return base64.b64encode(_dpapi(pin)).decode('ascii') if os.name=='nt' else None

def _visible_pin(token):
 if not token:return 'Restablecer PIN'
 try:return _dpapi(base64.b64decode(token),True).decode('utf-8')
 except Exception:return 'Restablecer PIN'

def list_users_admin():
 with connect() as db:
  rows=[dict(r) for r in db.execute('SELECT id,name,active,pin_secret FROM users ORDER BY name')]
 for r in rows:r['pin_display']=_visible_pin(r.pop('pin_secret',None))
 return rows

def lan_address():
 sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
 try:
  sock.connect(('192.0.2.1',80));ip=sock.getsockname()[0]
 except OSError:ip=socket.gethostbyname(socket.gethostname())
 finally:sock.close()
 return ip

_MOBILE_SERVER=None
def start_mobile_server(port=8766):
 global _MOBILE_SERVER
 if _MOBILE_SERVER:return lan_address()
 from werkzeug.serving import make_server
 server=make_server('0.0.0.0',port,make_app(),threaded=True)
 _MOBILE_SERVER=server
 threading.Thread(target=server.serve_forever,daemon=True,name='vigia-alerts-wifi').start()
 return lan_address()

def connect():
 db=sqlite3.connect(DB,timeout=5,check_same_thread=False)
 db.row_factory=sqlite3.Row
 db.execute('PRAGMA journal_mode=WAL')
 db.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, pin_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, version INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL)')
 if 'pin_secret' not in [r[1] for r in db.execute('PRAGMA table_info(users)')]:db.execute('ALTER TABLE users ADD COLUMN pin_secret TEXT')
 db.execute('CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY, time TEXT NOT NULL, camera INTEGER NOT NULL, event TEXT NOT NULL, detail TEXT, severity TEXT NOT NULL, acknowledged INTEGER NOT NULL DEFAULT 0)')
 db.commit()
 return db

def add_user(name,pin):
 name=name.strip()
 if not 1<=len(name)<=80 or not(pin.isdigit() and len(pin)==4):raise ValueError('Nombre y PIN de 4 dígitos obligatorios')
 with _LOCK:
  with connect() as db:
   db.execute('INSERT INTO users(name,pin_hash,pin_secret,created) VALUES(?,?,?,?)',(name,generate_password_hash(pin,method='pbkdf2:sha256:600000'),_protected_pin(pin),datetime.now().isoformat(timespec='seconds')))

def user_list():
 with connect() as db:return [dict(x) for x in db.execute('SELECT id,name,active,created FROM users ORDER BY name')]

def revoke(uid):
 with _LOCK:
  with connect() as db:db.execute('UPDATE users SET active=0, pin_secret=NULL, version=version+1 WHERE id=?',(uid,))

def reset_pin(uid,pin):
 if not(pin.isdigit() and len(pin)==4):raise ValueError('PIN de cuatro números')
 with _LOCK:
  with connect() as db:db.execute('UPDATE users SET pin_hash=?,pin_secret=?,active=1,version=version+1 WHERE id=?',(generate_password_hash(pin,method='pbkdf2:sha256:600000'),_protected_pin(pin),uid))

def add_alert(camera,event,detail='',severity='info'):
 with _LOCK:
  with connect() as db:
   db.execute('INSERT INTO alerts(time,camera,event,detail,severity) VALUES(?,?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),int(camera),event,str(detail)[:500],severity))

def recent_alerts(limit=80):
 with connect() as db:return [dict(x) for x in db.execute('SELECT * FROM alerts ORDER BY id DESC LIMIT ?', (min(int(limit),200),))]

_APP=None
_SERVER_ERROR=None
def wait_for_server(seconds=5):
 until=time.monotonic()+seconds
 while time.monotonic()<until:
  try:
   with urllib.request.urlopen('http://127.0.0.1:8765/',timeout=0.35) as response:
    return response.status==200
  except Exception:
   time.sleep(0.15)
 return False
def make_app():
 from flask import Flask,request,session,redirect,jsonify,render_template_string,Response
 app=Flask(__name__)
 app.secret_key=secrets.token_bytes(32)
 app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Strict')
 attempts={}
 def current_user():
  uid=session.get('uid');ver=session.get('version')
  if not uid:return None
  with connect() as db:r=db.execute('SELECT id,name,active,version FROM users WHERE id=?',(uid,)).fetchone()
  return r if r and r['active'] and r['version']==ver else None
 @app.after_request
 def headers(res):
  res.headers['Cache-Control']='no-store'
  res.headers['X-Content-Type-Options']='nosniff'
  res.headers['X-Frame-Options']='DENY'
  res.headers['Content-Security-Policy']="default-src 'self'; style-src 'unsafe-inline' 'self'; script-src 'unsafe-inline' 'self'"
  return res
 @app.route('/',methods=['GET','POST'])
 def index():
  err=''
  if request.method=='POST':
   name=request.form.get('name','').strip();pin=request.form.get('pin','')
   key=request.remote_addr or 'local';now=time.monotonic()
   record=attempts.get(key,[]);record=[x for x in record if now-x<600]
   if len(record)>=5:err='Demasiados intentos. Probá más tarde.'
   else:
    with connect() as db:r=db.execute('SELECT id,pin_hash,version,active FROM users WHERE name=?',(name,)).fetchone()
    if r and r['active'] and check_password_hash(r['pin_hash'],pin):
     attempts.pop(key,None);session.clear();session['uid']=r['id'];session['version']=r['version'];return redirect('/alertas')
    record.append(now);attempts[key]=record;err='Usuario o clave inválidos'
  return render_template_string('''<!doctype html><html lang="es"><meta name="viewport" content="width=device-width, initial-scale=1"><meta charset="utf-8"><title>VIGÍA ALERTAS</title><style>body{font-family:Arial,sans-serif;background:#0f1b2d;color:#ecf4ff;max-width:650px;margin:45px auto;padding:18px}input,button{padding:13px;margin:7px 0;width:100%;box-sizing:border-box;border-radius:8px;border:0}button{background:#33b9a6;font-weight:bold}section{background:#213047;padding:20px;border-radius:12px}.err{color:#ffbd98}</style><section><h1>🛡️ VIGÍA ALERTAS</h1><p>Acceso autorizado · Servidor local de demostración</p><form method="post"><input name="name" placeholder="Nombre de usuario" required autocomplete="username"><input name="pin" type="password" inputmode="numeric" minlength="4" maxlength="4" placeholder="PIN de 4 dígitos" required><button>Ingresar</button></form><p class="err">{{err}}</p></section></html>''',err=err)
 @app.route('/alertas')
 def alerts_page():
  user=current_user()
  if not user:return redirect('/')
  return render_template_string('''<!doctype html><html lang="es"><meta name="viewport" content="width=device-width, initial-scale=1"><meta charset="utf-8"><title>VIGÍA ALERTAS</title><style>body{font-family:Arial,sans-serif;background:#0f1b2d;color:#edf4ff;max-width:800px;margin:auto;padding:15px}article{background:#23364c;border-radius:10px;padding:15px;margin:12px 0}button{background:#33b9a6;padding:12px;border:0;border-radius:8px;font-size:1rem}.small{color:#bbcfde;font-size:.9rem}</style><h2>🔔 VIGÍA ALERTAS</h2><p>Sesión: {{name}} · <a style="color:#83e1d5" href="/salir">Salir</a></p><button onclick="enableSound()">Activar sonido de alertas</button><p class="small">Para sonidos, esta página debe permanecer abierta. Notificaciones push en segundo plano requieren un servicio HTTPS adicional.</p><div id="items">Cargando…</div><script>let old=0,enabled=false,audio;function enableSound(){try{audio=new(window.AudioContext||window.webkitAudioContext)();audio.resume();enabled=true;alert('Sonido activado mientras esta página esté abierta.')}catch(e){alert('Audio no disponible')}}function beep(){if(!enabled)return;let o=audio.createOscillator(),g=audio.createGain();o.connect(g);g.connect(audio.destination);o.frequency.value=900;g.gain.value=.08;o.start();o.stop(audio.currentTime+.25)}async function load(){try{let r=await fetch('/api/alertas',{cache:'no-store'});if(r.status===401){location.href='/';return}let data=await r.json();if(data.length && old && data[0].id>old)beep();if(data.length)old=data[0].id;document.getElementById('items').innerHTML='';for(let e of data){let a=document.createElement('article');let h=document.createElement('h3');h.textContent=e.event;let t=document.createElement('div');t.textContent=e.time.replace('T',' ')+' · Cámara '+e.camera;let p=document.createElement('p');p.textContent=e.detail||'';a.append(h,t,p);document.getElementById('items').append(a)} }catch(e){document.getElementById('items').textContent='Servidor sin respuesta'}}load();setInterval(load,5000);</script></html>''',name=user['name'])
 @app.route('/api/alertas')
 def alerts_api():
  if not current_user():return jsonify({'error':'no autorizado'}),401
  return jsonify(recent_alerts())
 @app.route('/salir')
 def logout():session.clear();return redirect('/')
 return app

def start_local_server(port=8765):
 global _APP
 if _APP:return
 _APP=make_app()
 def serve():
  global _SERVER_ERROR
  try:
   from werkzeug.serving import make_server
   httpd=make_server('127.0.0.1',port,_APP,threaded=True)
   httpd.serve_forever()
  except Exception as ex:
   _SERVER_ERROR=ex
 threading.Thread(target=serve,daemon=True,name='vigia-local-alerts').start()

VIGÍA IA - ENTREGA MINIMA

ARCHIVOS NECESARIOS
- INICIAR_MOSAICO_ISAPI.bat inicia las 12 posiciones (11 canales + 1 ciega).
- INSTALAR_ISAPI.bat instala dependencias para mosaico/alertas.
- INSTALAR_CONTADOR_IA.bat es opcional para deteccion experimental YOLO.
- vigia_mosaico_isapi.py: aplicacion.
- vigia_services.py: usuarios, historial, portal local.
- Enlace alertas.html: pagina estatica para GitHub Pages (ordenadores y celulares).

COMO UTILIZAR
1. Descomprimir en una carpeta, ejecutar INSTALAR_ISAPI.bat una vez.
2. Ejecutar INICIAR_MOSAICO_ISAPI.bat.
3. Abrir Usuarios y Accesos para crear personas/PIN y pulsar Enlace Alertas para probar en ESTA computadora.
4. Para GitHub Pages: publicar Enlace alertas.html como index.html en un repositorio con GitHub Pages.
5. ANTES de publicar, editar en el HTML la constante VIGIA_HTTPS_URL e introducir la URL HTTPS real, protegida, del servidor de alertas; sin ella el boton remoto aparece deshabilitado.

IMPORTANTE: GitHub Pages NO procesa Python ni conecta con una IP privada o localhost. La URL HTTPS del backend debe existir y mantenerse encendida. Esta entrega NO configura por si sola un servidor publico ni las notificaciones push. No compartir PIN por HTTP.

DATOS DEL USUARIO: si ya tenes historial/configuracion, respalda y conserva mosaico_isapi_config.json y vigia_alertas.db (y -wal/-shm si estan activos) desde la carpeta anterior. No se incluyen en este ZIP para evitar datos privados. No descomprimas encima de tu instalacion en marcha.

SEGURIDAD: Los PIN de 4 digitos son debiles para Internet. Requeris autentificacion mas robusta, HTTPS, limitacion de intentos y acceso admin separado antes de publicarlo para terceros.

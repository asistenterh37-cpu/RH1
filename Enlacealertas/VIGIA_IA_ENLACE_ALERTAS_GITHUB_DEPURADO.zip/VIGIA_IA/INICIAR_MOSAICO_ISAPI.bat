@echo off
cd /d "%~dp0"
py -3 vigia_mosaico_isapi.py
if errorlevel 1 (echo Error al abrir mosaico ISAPI. Ejecuta INSTALAR_ISAPI.bat primero. & pause)
